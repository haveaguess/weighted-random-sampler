package com.ahl.test;

import java.util.Random;

/**
 * @author Ben Ritchie
 */
public interface RandomNumberGenerator {
	public float random();
}
